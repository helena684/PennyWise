package com.example.pennywise.Tools;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.pennywise.R;

public class Constraints {
    public static String currency="currency";
    public static String cashforward="cashforward";
    public static String applock="applock";
    public static String theme="theme";
    public static String dateformat="dateformat";
    public static String userProfileName="username";
    public static String userProilfePurpose="profilepurpose";
    public static String userProilfePicPath="userpic";
    public static String userAdditionalInfo="useradditionalinfo";
    public static String path="";


    public static String userAccountIdentity="useraccountidentity";
    public static String userBankDetails="userbankdetails";
    public static String useropeningbalance="useropeningbalance";
    public static String userRegistered="userregistered";
    public static String userUID="userUID";

    public static String cashBalance="cashbalance";




}
